
$('.owl-carousel').owlCarousel({
    stagePadding: 372,
    loop:true,
    margin:30,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            stagePadding: 10,
        },
        600:{
            items:1,
            stagePadding: 30,
        },
        1000:{
            items:1,
        }
    }
})

$(document).ready(function(){
  $('.faq-item').on('click', function() {        
    $(this).find('p').toggle();
    $(this).find('.bb-down').toggle();
    $(this).find('.bb-up').toggle();
  });
});


  $(document).ready(function(){
    $('.faq-item .bb-up').on('click', function() {        
      $('.faq-item').find('.mt-3').hide();
      $(this).hide();
      $('.faq-item').find('.bb-down').show();
    });
  });


  const wait = (delay = 0) =>
  new Promise(resolve => setTimeout(resolve, delay));
  
  const setVisible = (elementOrSelector, visible) => 
  (typeof elementOrSelector === 'string'
  ? document.querySelector(elementOrSelector)
  : elementOrSelector
  ).style.display = visible ? 'block' : 'none';
  
  setVisible('.page', false);
  setVisible('#loading', true);
  
  document.addEventListener('DOMContentLoaded', () =>
  wait(300).then(() => {
      setVisible('.page', true);
      setVisible('#loading', false);
  }));


  